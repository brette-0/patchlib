"""
Import all patchlib subpackages.
"""
__version__ = "1.1"

import patchlib.ips